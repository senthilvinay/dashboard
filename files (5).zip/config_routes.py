# api/config_routes.py
"""
JAWS Platform — Config API Routes
Serves app branding, navigation, and theme configs to the frontend.
All endpoints under /api/config/

These endpoints allow the frontend to bootstrap itself dynamically from JSON,
enabling multi-app deployment without any HTML changes.
"""

import os
import json
import logging
from flask import Blueprint, jsonify, abort
from config.settings import ActiveConfig

logger = logging.getLogger(__name__)

config_bp = Blueprint("config", __name__, url_prefix="/api/config")


# ── Helpers ───────────────────────────────────────────────────

def _load_config(filename: str) -> dict | list | None:
    """Load a JSON file from the config root directory."""
    filepath = os.path.join(os.path.dirname(ActiveConfig.GLOBAL_CONFIG_FILE), filename)
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        logger.warning("Config file not found: %s", filepath)
        return None
    except json.JSONDecodeError as e:
        logger.error("Invalid JSON in %s: %s", filepath, e)
        return None


def _json_ok(data):
    return jsonify({"status": "ok", **data}) if isinstance(data, dict) else jsonify(data)


def _not_found(name):
    return jsonify({"status": "error", "message": f"{name} config not found"}), 404


# ── GET /api/config/app ───────────────────────────────────────
@config_bp.route("/app", methods=["GET"])
def get_app_config():
    """
    Returns main app branding: name, logo, subtitle, environment, user.
    Frontend uses this to render the sidebar logo + topbar title.
    """
    data = _load_config("app.json")
    if data is None:
        return _not_found("app")
    return jsonify({"status": "ok", "app": data})


# ── GET /api/config/nav ───────────────────────────────────────
@config_bp.route("/nav", methods=["GET"])
def get_nav_config():
    """
    Returns the full navigation tree: groups → items → children.
    Frontend renders the entire sidebar from this config.

    Schema:
    {
      "groups": [
        {
          "id":    "applications",
          "label": "Applications",
          "order": 2,
          "items": [
            {
              "id":           "jaws",
              "label":        "JAWS",
              "icon":         "fa-journal-whills",
              "accent_color": "#00e5ff",
              "expanded":     true,
              "children": [
                {
                  "id":    "jaws-dashboard",
                  "label": "Dashboard",
                  "icon":  "fa-th-large",
                  "page":  "dashboard"
                }
              ]
            }
          ]
        }
      ]
    }
    """
    data = _load_config("nav.json")
    if data is None:
        return _not_found("nav")
    return jsonify({"status": "ok", "nav": data})


# ── GET /api/config/themes ────────────────────────────────────
@config_bp.route("/themes", methods=["GET"])
def get_themes_config():
    """
    Returns all available themes.
    Frontend builds the theme switcher from this list.
    Teams add custom themes by editing themes.json — no code changes needed.
    """
    data = _load_config("themes.json")
    if data is None:
        return _not_found("themes")
    return jsonify({"status": "ok", "themes": data})


# ── GET /api/config/all ───────────────────────────────────────
@config_bp.route("/all", methods=["GET"])
def get_all_config():
    """
    Combined endpoint — returns app + nav + themes in a single request.
    Frontend calls this once at bootstrap to minimize round-trips.
    """
    app_cfg    = _load_config("app.json")
    nav_cfg    = _load_config("nav.json")
    themes_cfg = _load_config("themes.json")

    missing = []
    if app_cfg    is None: missing.append("app")
    if nav_cfg    is None: missing.append("nav")
    if themes_cfg is None: missing.append("themes")

    if missing:
        logger.warning("Missing config files: %s", missing)

    return jsonify({
        "status": "ok",
        "app":    app_cfg    or {},
        "nav":    nav_cfg    or {"groups": []},
        "themes": themes_cfg or {"themes": [], "default_theme": "dark"},
    })
