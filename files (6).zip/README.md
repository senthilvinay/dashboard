# JAWS MMNG — 30-Min Health Check Monitor

## Files
```
mmng_monitor/
├── CFS_DAILY_30MIN_HEALTHCHECK_MONITOR.py   ← main script
├── requirements.txt
├── config/
│   ├── settings.py          ← DB, Teams, email config
│   └── mmng_monitor.sql     ← monitoring SQL queries
└── mmng_monitor.log         ← auto-created on first run
```

## Setup
```bash
pip install pyodbc --break-system-packages

# freetds.conf entry (already done):
# [NYP_WM_JAWS_SEC_ORCH]
#   host = <actual-server-hostname>
#   port = 1433
#   tds version = 8.0
```

## Configure
Edit `config/settings.py`:
- `TEAMS_WEBHOOK_URL` → paste your Teams incoming webhook URL
- `EMAIL_TO`          → your team DL
- `SMTP_HOST`         → firm SMTP relay

## Run
```bash
python CFS_DAILY_30MIN_HEALTHCHECK_MONITOR.py
```

## Cron (every 30 min)
```
*/30 * * * * /usr/bin/python3 /opt/jaws/mmng_monitor/CFS_DAILY_30MIN_HEALTHCHECK_MONITOR.py
```

## Alert Logic
| Condition                  | State    |
|----------------------------|----------|
| Queue count > 0            | BAD/RED  |
| Pending time > 15 min      | BAD/RED  |
| Warehoused journals > 1000 | BAD/RED  |
| Processing time > 300s     | WARNING  |

## Exit Codes
- `0` = GOOD
- `1` = BAD/RED (use this in monitoring wrappers)
