# =============================================================
# config/settings.py  —  MMNG 30-Min Health Check Monitor
# =============================================================

import os

# ── Database ──────────────────────────────────────────────────
DB_SERVER   = "NYP_WM_JAWS_SEC_ORCH"          # logical name in freetds.conf
DB_NAME     = "JAWS_SEC_ORCH"
DB_DRIVER   = "FreeTDS"
DB_TIMEOUT  = 30                               # seconds

# Optional: override with env vars for CI/CD
DB_USER     = os.getenv("JAWS_DB_USER", "")    # leave blank for Windows Auth
DB_PASSWORD = os.getenv("JAWS_DB_PASS", "")

# ── SQL file path ─────────────────────────────────────────────
SQL_PATH = os.path.join(os.path.dirname(__file__), "mmng_monitor.sql")

# ── Alert thresholds ──────────────────────────────────────────
ALERT_QUEUE_THRESHOLD       = 0     # queue count > 0  → BAD
ALERT_PENDING_MINUTES       = 15    # pending > 15 min → BAD
ALERT_WAREHOUSE_THRESHOLD   = 1000  # warehoused > 1000 → BAD
ALERT_PROC_TIME_THRESHOLD   = 300   # processing time > 300s → WARNING

# ── Microsoft Teams ───────────────────────────────────────────
TEAMS_WEBHOOK_URL = os.getenv(
    "TEAMS_WEBHOOK_URL",
    "https://outlook.office.com/webhook/YOUR-WEBHOOK-URL-HERE"
)
TEAMS_ENABLED = True   # set False to disable

# ── Email ─────────────────────────────────────────────────────
EMAIL_ENABLED       = True
SMTP_HOST           = "smtp.morganstanley.com"
SMTP_PORT           = 25
EMAIL_FROM          = "jaws-monitor@morganstanley.com"
EMAIL_TO            = [
    "your-team-dl@morganstanley.com",
]
EMAIL_CC            = []
EMAIL_SUBJECT_GOOD  = "[JAWS MMNG] ✅ GOOD — 30-Min Health Check"
EMAIL_SUBJECT_BAD   = "[JAWS MMNG] 🚨 BAD/RED — 30-Min Health Check ALERT"

# ── Script metadata ───────────────────────────────────────────
SCRIPT_VERSION  = "1.0.0"
ENVIRONMENT     = os.getenv("ENV", "PROD")       # PROD / QA / DEV
RUN_INTERVAL_MIN = 30
