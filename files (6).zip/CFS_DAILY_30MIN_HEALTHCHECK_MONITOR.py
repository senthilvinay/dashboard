#!/usr/bin/env python3
"""
=================================================================
CFS_DAILY_30MIN_HEALTHCHECK_MONITOR.py
-----------------------------------------------------------------
30-Minute Health Check Monitor for JAWS MMNG
(Journal Management & Orchestration System)

What this script does:
  1. Connects to JAWS_SEC_ORCH SQL Server via FreeTDS / pyodbc
  2. Loads and executes the monitoring SQL from config path
  3. Evaluates health alert logic (queue, lag, warehouse)
  4. Sends a formatted Teams channel message (every run)
  5. Sends a rich HTML email alert (only on BAD/RED state)

Alert Rules:
  - Queue count > 0           → backlog detected
  - Pending time > 15 min     → system state BAD / RED
  - Warehoused journals > 1000 → system state BAD / RED

DB  : JAWS_SEC_ORCH
DSN : NYP_WM_JAWS_SEC_ORCH  (defined in freetds.conf)
=================================================================
"""

import sys
import os
import re
import logging
import smtplib
import json
import urllib.request
import urllib.error
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dataclasses import dataclass, field
from typing import List, Tuple, Optional

# Add config dir to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "config"))
import settings

try:
    import pyodbc
except ImportError:
    print("ERROR: pyodbc not installed. Run: pip install pyodbc")
    sys.exit(1)

# =================================================================
#  LOGGING
# =================================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  [%(levelname)s]  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("mmng_monitor.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("MMNG-Monitor")


# =================================================================
#  DATA MODELS
# =================================================================
@dataclass
class MonitorRow:
    item:   str
    dt:     str
    value:  str

@dataclass
class HealthState:
    status:       str   = "GOOD"         # GOOD | BAD
    color:        str   = "#00875a"      # green | red
    alerts:       List[str] = field(default_factory=list)
    warnings:     List[str] = field(default_factory=list)
    queues:       dict  = field(default_factory=dict)   # queue_name → count
    pending_times: dict = field(default_factory=dict)   # queue_name → datetime
    warehouse_count: int = 0


# =================================================================
#  DATABASE CONNECTION
# =================================================================
def get_connection():
    """
    Establish pyodbc connection using FreeTDS DSN.
    Mirrors the existing firm connection pattern.
    """
    if settings.DB_USER:
        conn_str = (
            f"DRIVER={{{settings.DB_DRIVER}}};"
            f"SERVER={settings.DB_SERVER};"
            f"DATABASE={settings.DB_NAME};"
            f"UID={settings.DB_USER};"
            f"PWD={settings.DB_PASSWORD};"
            f"TDS_Version=8.0;"
            f"Port=1433;"
        )
    else:
        # Windows / Kerberos auth
        conn_str = (
            f"DRIVER={{{settings.DB_DRIVER}}};"
            f"SERVER={settings.DB_SERVER};"
            f"DATABASE={settings.DB_NAME};"
            f"Trusted_Connection=yes;"
            f"TDS_Version=8.0;"
        )
    log.info(f"Connecting → {settings.DB_SERVER} / {settings.DB_NAME}")
    conn = pyodbc.connect(conn_str, timeout=settings.DB_TIMEOUT)
    conn.autocommit = True
    return conn


# =================================================================
#  SQL LOADER
# =================================================================
def load_sql(path: str) -> str:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"SQL file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


# =================================================================
#  EXECUTE MONITORING SQL
# =================================================================
def run_monitor_sql(conn) -> List[MonitorRow]:
    """
    Execute the monitoring SQL (multi-statement with temp table).
    Splits on GO / semicolon batches and collects the final result set.
    """
    sql_raw = load_sql(settings.SQL_PATH)

    # Split into individual batches on semicolons (keeping DROP at end)
    # We execute each batch separately because pyodbc doesn't support
    # multi-statement batches with temp tables in a single execute().
    batches = _split_batches(sql_raw)

    cursor = conn.cursor()
    rows: List[MonitorRow] = []

    for i, batch in enumerate(batches):
        batch = batch.strip()
        if not batch:
            continue
        try:
            cursor.execute(batch)
            # Collect rows from any SELECT that returns results
            if cursor.description:
                for row in cursor.fetchall():
                    rows.append(MonitorRow(
                        item  = str(row[0]).strip() if row[0] else "",
                        dt    = str(row[1]).strip() if len(row) > 1 and row[1] else "",
                        value = str(row[2]).strip() if len(row) > 2 and row[2] else "",
                    ))
        except Exception as e:
            log.warning(f"Batch {i+1} error: {e}\nSQL: {batch[:120]}…")

    cursor.close()
    log.info(f"SQL returned {len(rows)} rows")
    return rows


def _split_batches(sql: str) -> List[str]:
    """Split SQL on GO keyword or semicolons used as batch separators."""
    # Remove single-line comments
    sql = re.sub(r"--[^\n]*", "", sql)
    # Split on GO (standalone line) or semicolons
    parts = re.split(r"\bGO\b|;", sql, flags=re.IGNORECASE)
    return [p.strip() for p in parts if p.strip()]


# =================================================================
#  HEALTH EVALUATION
# =================================================================
def evaluate_health(rows: List[MonitorRow]) -> HealthState:
    state = HealthState()
    now   = datetime.now()

    for row in rows:
        item  = row.item.upper()
        value = row.value.strip()
        dt_str = row.dt.strip()

        # ── Queue counts ──────────────────────────────────────
        if any(k in item for k in ["SUBMITTED QUEUE", "APPROVED QUEUE", "OTHER EVENTS QUEUE"]):
            # skip date-breakdown sub-rows (they have a date in dt column)
            if dt_str and re.match(r"\d{4}-\d{2}-\d{2}", dt_str):
                continue
            try:
                count = int(value)
            except ValueError:
                count = 0
            label = _queue_label(item)
            state.queues[label] = count
            if count > settings.ALERT_QUEUE_THRESHOLD:
                state.alerts.append(f"Queue backlog detected — {label}: {count} pending")

        # ── Pending since ─────────────────────────────────────
        if "PENDING SINCE" in item and value not in ("", "Nothing New Pending"):
            try:
                pending_dt = datetime.strptime(value[:16], "%Y-%m-%d %H:%M")
                lag_minutes = (now - pending_dt).total_seconds() / 60
                label = _queue_label(item)
                state.pending_times[label] = pending_dt
                if lag_minutes > settings.ALERT_PENDING_MINUTES:
                    state.alerts.append(
                        f"SLA breach — {label} pending {int(lag_minutes)} min "
                        f"(since {value})"
                    )
            except ValueError:
                pass

        # ── Warehoused count ──────────────────────────────────
        if "13. MMNG WAREHOUSED" in item and not dt_str:
            try:
                wh_count = int(value)
                state.warehouse_count = wh_count
                if wh_count > settings.ALERT_WAREHOUSE_THRESHOLD:
                    state.alerts.append(
                        f"Warehouse backlog — {wh_count} journals in FEWRH/MSOWRH "
                        f"(threshold: {settings.ALERT_WAREHOUSE_THRESHOLD})"
                    )
            except ValueError:
                pass

        # ── Processing time warnings ──────────────────────────
        if "90TH" in item or "90 PCTL" in item or "PERCENTILE" in item:
            try:
                secs = float(value)
                if secs > settings.ALERT_PROC_TIME_THRESHOLD:
                    state.warnings.append(
                        f"High processing time — {_queue_label(item)}: {int(secs)}s "
                        f"(90th pctl)"
                    )
            except ValueError:
                pass

    # ── Final state decision ──────────────────────────────────
    if state.alerts:
        state.status = "BAD"
        state.color  = "#de350b"

    return state


def _queue_label(item: str) -> str:
    """Extract a short readable label from a reporting item string."""
    item = re.sub(r"^\d+[\.\d]*\s*", "", item)   # strip leading "02. " etc.
    item = item.replace("MMNG_", "").replace("MMNG ", "").strip()
    return item.title()[:40]


# =================================================================
#  HTML EMAIL BUILDER
# =================================================================
def build_html_email(rows: List[MonitorRow], state: HealthState) -> str:
    run_time = datetime.now().strftime("%d %b %Y  %H:%M:%S")
    is_bad   = state.status == "BAD"

    status_color   = "#de350b" if is_bad else "#00875a"
    status_bg      = "#fff0ee" if is_bad else "#e3fcef"
    status_border  = "#de350b" if is_bad else "#00875a"
    status_icon    = "🚨" if is_bad else "✅"
    status_label   = "BAD / RED — Action Required" if is_bad else "GOOD — All Systems Healthy"
    header_bg      = "#de350b" if is_bad else "#0052cc"

    # ── Alert box HTML ────────────────────────────────────────
    alert_html = ""
    if state.alerts:
        items_html = "".join(
            f'<li style="margin:5px 0;color:#de350b;font-size:13px;">⚠ {a}</li>'
            for a in state.alerts
        )
        alert_html = f"""
        <div style="margin:16px 0;padding:14px 18px;background:#fff5f5;
                    border-left:4px solid #de350b;border-radius:6px;">
          <div style="font-weight:700;color:#de350b;margin-bottom:8px;font-size:14px;">
            🚨 Active Alerts ({len(state.alerts)})
          </div>
          <ul style="margin:0;padding-left:18px;">{items_html}</ul>
        </div>"""

    warning_html = ""
    if state.warnings:
        items_html = "".join(
            f'<li style="margin:4px 0;color:#974f0c;font-size:13px;">⚡ {w}</li>'
            for w in state.warnings
        )
        warning_html = f"""
        <div style="margin:12px 0;padding:12px 18px;background:#fffae6;
                    border-left:4px solid #ff8b00;border-radius:6px;">
          <div style="font-weight:700;color:#974f0c;margin-bottom:7px;font-size:13px;">
            ⚡ Warnings ({len(state.warnings)})
          </div>
          <ul style="margin:0;padding-left:18px;">{items_html}</ul>
        </div>"""

    # ── Queue summary cards ───────────────────────────────────
    card_html = ""
    for label, count in state.queues.items():
        card_color = "#de350b" if count > 0 else "#00875a"
        card_bg    = "#fff5f5" if count > 0 else "#e3fcef"
        card_html += f"""
        <div style="flex:1;min-width:150px;padding:14px 16px;background:{card_bg};
                    border:1px solid {card_color}44;border-radius:8px;text-align:center;">
          <div style="font-size:22px;font-weight:800;color:{card_color};">{count}</div>
          <div style="font-size:11px;color:#5e6c84;margin-top:3px;">{label}</div>
        </div>"""

    if state.warehouse_count is not None:
        wh_color = "#de350b" if state.warehouse_count > settings.ALERT_WAREHOUSE_THRESHOLD else "#0052cc"
        wh_bg    = "#fff5f5" if state.warehouse_count > settings.ALERT_WAREHOUSE_THRESHOLD else "#e6f0ff"
        card_html += f"""
        <div style="flex:1;min-width:150px;padding:14px 16px;background:{wh_bg};
                    border:1px solid {wh_color}44;border-radius:8px;text-align:center;">
          <div style="font-size:22px;font-weight:800;color:{wh_color};">{state.warehouse_count}</div>
          <div style="font-size:11px;color:#5e6c84;margin-top:3px;">Warehoused</div>
        </div>"""

    # ── Full result table ─────────────────────────────────────
    table_rows_html = ""
    prev_section = None
    SECTION_MARKERS = ["--", "HEADER", "SECTION"]

    for row in rows:
        is_section = (
            row.item.startswith("0") and "--" in row.item
            or row.dt == "Date/Time"
        )
        if is_section:
            section_title = row.item.replace("--", "").strip()
            table_rows_html += f"""
            <tr>
              <td colspan="3" style="background:#0052cc;color:#fff;font-size:12px;
                  font-weight:700;padding:9px 14px;letter-spacing:0.8px;
                  text-transform:uppercase;">{section_title}</td>
            </tr>"""
        else:
            # Colour-code value cell
            val_color = "#172b4d"
            val_bg    = "transparent"
            val_lower = row.value.lower()
            if "nothing new pending" in val_lower:
                val_color = "#00875a"
                val_bg    = "#e3fcef"
            elif row.value.lstrip("-").isdigit() and int(row.value) > 0:
                # Non-zero count
                val_color = "#de350b"
                val_bg    = "#fff5f5"
            elif row.item.strip().startswith("13.") and row.value.lstrip("-").isdigit():
                val_color = "#0052cc"

            table_rows_html += f"""
            <tr style="border-bottom:1px solid #f4f5f7;">
              <td style="padding:8px 14px;font-size:12px;color:#172b4d;">{row.item}</td>
              <td style="padding:8px 14px;font-size:12px;color:#5e6c84;white-space:nowrap;">{row.dt}</td>
              <td style="padding:8px 14px;font-size:12px;font-weight:600;
                  color:{val_color};background:{val_bg};">{row.value}</td>
            </tr>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>JAWS MMNG Health Check</title>
</head>
<body style="margin:0;padding:0;background:#f4f5f7;font-family:'Segoe UI',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f7;padding:24px 0;">
<tr><td align="center">
<table width="680" cellpadding="0" cellspacing="0"
       style="background:#fff;border-radius:12px;overflow:hidden;
              box-shadow:0 4px 20px rgba(0,0,0,.12);">

  <!-- HEADER BANNER -->
  <tr>
    <td style="background:{header_bg};padding:0;">
      <!-- MS Navy strip -->
      <div style="background:#001f5b;padding:10px 28px;display:flex;align-items:center;">
        <span style="color:#fff;font-size:13px;font-weight:800;
              letter-spacing:.1em;text-transform:uppercase;">Morgan Stanley</span>
        <span style="color:#ffffff66;margin:0 10px;">|</span>
        <span style="color:#ffffffcc;font-size:12px;">JAWS — Core Processing 360°</span>
      </div>
      <div style="padding:22px 28px 20px;">
        <div style="color:#ffffff99;font-size:11px;text-transform:uppercase;
             letter-spacing:1.5px;margin-bottom:6px;">30-Min Health Check Monitor</div>
        <div style="color:#fff;font-size:22px;font-weight:800;">
          {status_icon} &nbsp;MMNG System Status
        </div>
        <div style="color:#ffffff99;font-size:12px;margin-top:6px;">
          Run at {run_time} &nbsp;·&nbsp; Environment: {settings.ENVIRONMENT}
          &nbsp;·&nbsp; v{settings.SCRIPT_VERSION}
        </div>
      </div>
    </td>
  </tr>

  <!-- STATUS BADGE -->
  <tr>
    <td style="padding:20px 28px 12px;">
      <div style="display:inline-block;padding:10px 22px;
           background:{status_bg};border:2px solid {status_border};
           border-radius:30px;font-size:15px;font-weight:800;
           color:{status_color};">{status_icon} &nbsp;{status_label}</div>
    </td>
  </tr>

  <!-- ALERTS -->
  <tr><td style="padding:0 28px;">{alert_html}{warning_html}</td></tr>

  <!-- QUEUE SUMMARY CARDS -->
  {'<tr><td style="padding:12px 28px;"><div style="display:flex;gap:10px;flex-wrap:wrap;">' + card_html + '</div></td></tr>' if card_html else ''}

  <!-- DIVIDER -->
  <tr><td style="padding:4px 28px;">
    <hr style="border:none;border-top:1px solid #dfe1e6;margin:8px 0;">
  </td></tr>

  <!-- FULL RESULTS TABLE -->
  <tr>
    <td style="padding:8px 28px 24px;">
      <div style="font-size:13px;font-weight:700;color:#172b4d;margin-bottom:12px;
           text-transform:uppercase;letter-spacing:1px;">
        📋 Full Monitoring Report
      </div>
      <table width="100%" cellpadding="0" cellspacing="0"
             style="border-collapse:collapse;border-radius:8px;overflow:hidden;
                    border:1px solid #dfe1e6;">
        <thead>
          <tr style="background:#f4f5f7;">
            <th style="text-align:left;padding:9px 14px;font-size:11px;color:#5e6c84;
                font-weight:700;text-transform:uppercase;letter-spacing:.8px;
                border-bottom:2px solid #dfe1e6;">Reporting Item</th>
            <th style="text-align:left;padding:9px 14px;font-size:11px;color:#5e6c84;
                font-weight:700;text-transform:uppercase;letter-spacing:.8px;
                border-bottom:2px solid #dfe1e6;white-space:nowrap;">Date / Time</th>
            <th style="text-align:left;padding:9px 14px;font-size:11px;color:#5e6c84;
                font-weight:700;text-transform:uppercase;letter-spacing:.8px;
                border-bottom:2px solid #dfe1e6;">Counts / Timings</th>
          </tr>
        </thead>
        <tbody>{table_rows_html}</tbody>
      </table>
    </td>
  </tr>

  <!-- FOOTER -->
  <tr>
    <td style="background:#f4f5f7;padding:16px 28px;border-top:1px solid #dfe1e6;">
      <div style="font-size:11px;color:#97a0af;">
        This is an automated alert from <strong>CFS_DAILY_30MIN_HEALTHCHECK_MONITOR</strong>
        &nbsp;·&nbsp; DB: {settings.DB_NAME} on {settings.DB_SERVER}
        &nbsp;·&nbsp; Do not reply to this email.
      </div>
    </td>
  </tr>

</table>
</td></tr>
</table>
</body>
</html>"""
    return html


# =================================================================
#  TEAMS MESSAGE BUILDER
# =================================================================
def build_teams_payload(rows: List[MonitorRow], state: HealthState) -> dict:
    """
    Build an Adaptive Card payload for Teams webhook.
    """
    run_time  = datetime.now().strftime("%d %b %Y  %H:%M:%S")
    is_bad    = state.status == "BAD"
    color     = "attention" if is_bad else "good"
    icon      = "🚨" if is_bad else "✅"
    status_lbl = "BAD / RED — Action Required" if is_bad else "GOOD — All Systems Healthy"

    # Build table rows for Teams (limit to key rows for readability)
    table_rows = []
    for row in rows:
        if "--" in row.item and row.dt == "Date/Time":
            # Section header
            table_rows.append({
                "type": "TableRow",
                "cells": [
                    {"type": "TableCell", "items": [
                        {"type": "TextBlock",
                         "text": row.item.replace("--", "").strip(),
                         "weight": "Bolder", "color": "Accent",
                         "size": "Small", "wrap": True}
                    ]},
                    {"type": "TableCell", "items": [{"type": "TextBlock", "text": ""}]},
                    {"type": "TableCell", "items": [{"type": "TextBlock", "text": ""}]},
                ]
            })
        else:
            val_color = "Attention" if (
                row.value.lstrip("-").isdigit() and int(row.value or 0) > 0
                and "pending" not in row.item.lower()
            ) else (
                "Good" if "nothing new pending" in row.value.lower() else "Default"
            )
            table_rows.append({
                "type": "TableRow",
                "cells": [
                    {"type": "TableCell", "items": [
                        {"type": "TextBlock", "text": row.item,
                         "size": "Small", "wrap": True}
                    ]},
                    {"type": "TableCell", "items": [
                        {"type": "TextBlock", "text": row.dt or "",
                         "size": "Small", "isSubtle": True}
                    ]},
                    {"type": "TableCell", "items": [
                        {"type": "TextBlock", "text": row.value or "—",
                         "size": "Small", "weight": "Bolder",
                         "color": val_color, "wrap": True}
                    ]},
                ]
            })

    # Alert facts
    alert_facts = []
    for a in state.alerts:
        alert_facts.append({"title": "🚨", "value": a})
    for w in state.warnings:
        alert_facts.append({"title": "⚡", "value": w})

    body = [
        # Title bar
        {
            "type": "Container",
            "style": "emphasis",
            "items": [
                {
                    "type": "ColumnSet",
                    "columns": [
                        {
                            "type": "Column", "width": "stretch",
                            "items": [
                                {"type": "TextBlock",
                                 "text": f"{icon}  JAWS MMNG — 30-Min Health Check",
                                 "weight": "Bolder", "size": "Large", "wrap": True},
                                {"type": "TextBlock",
                                 "text": f"{status_lbl}",
                                 "color": color, "weight": "Bolder", "wrap": True},
                                {"type": "TextBlock",
                                 "text": f"🕐 {run_time}  ·  {settings.ENVIRONMENT}",
                                 "isSubtle": True, "size": "Small"},
                            ]
                        }
                    ]
                }
            ]
        },
    ]

    # Queue summary
    if state.queues:
        queue_cols = []
        for label, count in state.queues.items():
            q_color = "Attention" if count > 0 else "Good"
            queue_cols.append({
                "type": "Column", "width": "stretch",
                "items": [
                    {"type": "TextBlock", "text": str(count),
                     "weight": "Bolder", "size": "ExtraLarge",
                     "color": q_color, "horizontalAlignment": "Center"},
                    {"type": "TextBlock", "text": label,
                     "size": "Small", "isSubtle": True,
                     "horizontalAlignment": "Center", "wrap": True},
                ]
            })
        body.append({
            "type": "Container",
            "items": [
                {"type": "TextBlock", "text": "Queue Summary",
                 "weight": "Bolder", "spacing": "Medium"},
                {"type": "ColumnSet", "columns": queue_cols}
            ]
        })

    # Alerts
    if alert_facts:
        body.append({
            "type": "Container",
            "style": "attention",
            "items": [
                {"type": "TextBlock", "text": f"Active Alerts ({len(state.alerts)})",
                 "weight": "Bolder", "color": "Attention"},
                {"type": "FactSet", "facts": alert_facts}
            ]
        })

    # Full data table (split at ~20 rows to stay under Teams limit)
    chunk_size = 20
    for i in range(0, len(table_rows), chunk_size):
        chunk = table_rows[i:i + chunk_size]
        body.append({
            "type": "Table",
            "firstRowAsHeaders": False,
            "columns": [
                {"width": 3}, {"width": 1}, {"width": 2}
            ],
            "rows": chunk,
            "spacing": "Medium",
        })

    payload = {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.5",
                    "body": body,
                    "actions": [
                        {
                            "type": "Action.OpenUrl",
                            "title": "Open JAWS Dashboard",
                            "url": "http://jaws-dashboard.morganstanley.com"
                        }
                    ]
                }
            }
        ]
    }
    return payload


# =================================================================
#  SEND TEAMS
# =================================================================
def send_teams(rows: List[MonitorRow], state: HealthState) -> bool:
    if not settings.TEAMS_ENABLED:
        log.info("Teams disabled — skipping")
        return True
    if "YOUR-WEBHOOK-URL-HERE" in settings.TEAMS_WEBHOOK_URL:
        log.warning("Teams webhook URL not configured — skipping")
        return False

    payload = build_teams_payload(rows, state)
    data    = json.dumps(payload).encode("utf-8")
    req     = urllib.request.Request(
        settings.TEAMS_WEBHOOK_URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            body = resp.read().decode("utf-8")
            log.info(f"Teams message sent — HTTP {resp.status}  {body[:60]}")
            return True
    except urllib.error.HTTPError as e:
        log.error(f"Teams HTTP error {e.code}: {e.read().decode()[:200]}")
    except Exception as e:
        log.error(f"Teams send failed: {e}")
    return False


# =================================================================
#  SEND EMAIL
# =================================================================
def send_email(rows: List[MonitorRow], state: HealthState) -> bool:
    if not settings.EMAIL_ENABLED:
        log.info("Email disabled — skipping")
        return True

    is_bad  = state.status == "BAD"
    subject = settings.EMAIL_SUBJECT_BAD if is_bad else settings.EMAIL_SUBJECT_GOOD

    html_body = build_html_email(rows, state)

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = settings.EMAIL_FROM
    msg["To"]      = ", ".join(settings.EMAIL_TO)
    if settings.EMAIL_CC:
        msg["Cc"] = ", ".join(settings.EMAIL_CC)

    # Plain text fallback
    plain = f"""JAWS MMNG 30-Min Health Check
Status : {state.status}
Run at : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Alerts : {len(state.alerts)}
{chr(10).join(state.alerts)}

See HTML version for full report.
"""
    msg.attach(MIMEText(plain, "plain"))
    msg.attach(MIMEText(html_body, "html"))

    all_recipients = settings.EMAIL_TO + settings.EMAIL_CC
    try:
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=15) as smtp:
            smtp.sendmail(settings.EMAIL_FROM, all_recipients, msg.as_string())
        log.info(f"Email sent → {', '.join(settings.EMAIL_TO)}  |  Subject: {subject}")
        return True
    except Exception as e:
        log.error(f"Email send failed: {e}")
        return False


# =================================================================
#  MAIN
# =================================================================
def main():
    log.info("=" * 65)
    log.info(f"  JAWS MMNG 30-Min Health Check  —  v{settings.SCRIPT_VERSION}")
    log.info(f"  Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log.info("=" * 65)

    # 1. Connect to DB
    try:
        conn = get_connection()
    except Exception as e:
        log.critical(f"Cannot connect to {settings.DB_SERVER}: {e}")
        sys.exit(1)

    # 2. Run SQL
    try:
        rows = run_monitor_sql(conn)
    except Exception as e:
        log.critical(f"SQL execution failed: {e}")
        conn.close()
        sys.exit(1)
    finally:
        conn.close()

    if not rows:
        log.error("No data returned from monitoring SQL")
        sys.exit(1)

    # 3. Evaluate health
    state = evaluate_health(rows)
    log.info(f"Health state: {state.status}")
    log.info(f"  Queues    : {state.queues}")
    log.info(f"  Warehouse : {state.warehouse_count}")
    log.info(f"  Alerts    : {len(state.alerts)}")
    for a in state.alerts:
        log.warning(f"  ALERT → {a}")
    for w in state.warnings:
        log.warning(f"  WARN  → {w}")

    # 4. Send Teams (every run)
    log.info("Sending Teams notification…")
    send_teams(rows, state)

    # 5. Send email:
    #    - BAD state  → always send
    #    - GOOD state → send (change to `if state.status == "BAD":` for BAD-only)
    log.info(f"Sending email ({state.status} state)…")
    send_email(rows, state)

    log.info(f"Run complete — status: {state.status}")
    log.info("=" * 65)

    # Return exit code so cron/scheduler can detect failures
    sys.exit(0 if state.status == "GOOD" else 1)


if __name__ == "__main__":
    main()
